<html>
	<head>
		<title>Saludo</title>
	</head>
	<body>
		<b>Bienvenido, </b> <?= $usuario_nombre ?>
	</body>
</html>
